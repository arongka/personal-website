# Personalwebsite
develop A simple personal website using html and css.
its a practice project to learn html and css.
this contains:
•	personal information with photograph.
•	Detailed Academic information.
•	Description of Interests.
• photo album.
•	Links to a collection of useful web site.
• visitor can send mail.
